package com.example.prova.service;

import com.example.prova.model.Evento;
import com.example.prova.repository.EventoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class EventoService {

    @Autowired
    private EventoRepository eventoRepository;

    public Evento createEvento(Evento evento) {
        evento.setStatus("ATIVO");
        return eventoRepository.save(evento);
    }

    public List<Evento> getAllEventos() {
        return eventoRepository.findAll();
    }

    public Optional<Evento> getEventoById(Long id) {
        return eventoRepository.findById(id);
    }

    public Evento updateEvento(Long id, Evento eventoDetails) {
        Evento evento = eventoRepository.findById(id).orElseThrow();
        evento.setNomeEvento(eventoDetails.getNomeEvento());
        evento.setDescricao(eventoDetails.getDescricao());
        evento.setDataEvento(eventoDetails.getDataEvento());
        evento.setLocalEvento(eventoDetails.getLocalEvento());
        evento.setIdGestorResponsavel(eventoDetails.getIdGestorResponsavel());
        return eventoRepository.save(evento);
    }

    public void deleteEvento(Long id) {
        eventoRepository.deleteById(id);
    }

    public Evento cancelEvento(Long id) {
        Evento evento = eventoRepository.findById(id).orElseThrow();
        evento.setStatus("CANCELADO");
        return eventoRepository.save(evento);
    }

    public Evento closeEvento(Long id) {
        Evento evento = eventoRepository.findById(id).orElseThrow();
        evento.setStatus("ENCERRADO");
        return eventoRepository.save(evento);
    }

    public List<Evento> getEventosByNome(String nome) {
        return eventoRepository.findAll().stream()
                .filter(evento -> evento.getNomeEvento().toLowerCase().contains(nome.toLowerCase()))
                .toList();
    }

    public List<Evento> getEventosByData(String data) {
        LocalDateTime dataFormatada = LocalDateTime.parse(data);
        return eventoRepository.findAll().stream()
                .filter(evento -> evento.getDataEvento().toLocalDate().equals(dataFormatada.toLocalDate()))
                .toList();
    }

    public List<Evento> getEventosByGestor(Long idGestor) {
        return eventoRepository.findAll().stream()
                .filter(evento -> evento.getIdGestorResponsavel().equals(idGestor))
                .toList();
    }
}
