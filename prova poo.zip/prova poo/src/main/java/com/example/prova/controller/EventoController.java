package com.example.prova.controller;

import com.example.prova.model.Evento;
import com.example.prova.service.EventoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/eventos")
public class EventoController {

    @Autowired
    private EventoService eventoService;

    @PostMapping
    public Evento createEvento(@RequestBody Evento evento) {
        return eventoService.createEvento(evento);
    }

    @GetMapping
    public List<Evento> getAllEventos() {
        return eventoService.getAllEventos();
    }

    @GetMapping("/nome/{nome}")
    public List<Evento> getEventosByNome(@PathVariable String nome) {
        return eventoService.getEventosByNome(nome);
    }

    @GetMapping("/data/{data}")
    public List<Evento> getEventosByData(@PathVariable String data) {
        return eventoService.getEventosByData(data);
    }

    @GetMapping("/gestor/{idGestor}")
    public List<Evento> getEventosByGestor(@PathVariable Long idGestor) {
        return eventoService.getEventosByGestor(idGestor);
    }

    @PutMapping("/{id}")
    public Evento updateEvento(@PathVariable Long id, @RequestBody Evento eventoDetails) {
        return eventoService.updateEvento(id, eventoDetails);
    }

    @PutMapping("/{id}/cancelar")
    public Evento cancelEvento(@PathVariable Long id) {
        return eventoService.cancelEvento(id);
    }

    @PutMapping("/{id}/encerrar")
    public Evento closeEvento(@PathVariable Long id) {
        return eventoService.closeEvento(id);
    }

    @DeleteMapping("/{id}")
    public void deleteEvento(@PathVariable Long id) {
        eventoService.deleteEvento(id);
    }
}
